# Beta Club Robot
This is the RobotC files for our entry into the Beta Club Robotics competition.